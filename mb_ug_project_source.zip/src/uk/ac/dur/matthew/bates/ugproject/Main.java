package uk.ac.dur.matthew.bates.ugproject;

import java.util.ArrayList;
import java.util.Random;

import uk.ac.dur.matthew.bates.ugproject.gui.MapGenerator;
import uk.ac.dur.matthew.bates.ugproject.hpl2.util.PathConfig;
import uk.ac.dur.matthew.bates.ugproject.model.FloorPlan;

public class Main
{
	public static void main(String[] args)
	{
		Random r = new Random();

//		List<Integer> xs = new ArrayList<Integer>();
		
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < 13000; i++)
		{
			int width = r.nextInt(10) + 20;
			int height = r.nextInt(20) + 20;
			int n = r.nextInt(4) + 7;
			ArrayList<Double> areas = new ArrayList<Double>();
			for (int j = 0; j < n; j++)
			{
				areas.add((double) (r.nextInt(3) + 4));
			}
			FloorPlan fp = new FloorPlan(width, height, areas);
			fp = fp.normalizeRoomSizes();
			MapGenerator mg = new MapGenerator(fp);
			mg.writeToFile(PathConfig.AMNESIA_RESOURCES_DIR + "maps/UGProject/maps/map"+ i +".map");
			
//			if (!fp.privacyProblems(0).isEmpty()) xs.add(1) ;
			
		}
		System.out.println(System.currentTimeMillis() - startTime);

//		int sum = 0;
//		for (int i : xs)
//		{
//			sum += i;
//		}
//		
//		System.out.println(sum);
		
	}
}
