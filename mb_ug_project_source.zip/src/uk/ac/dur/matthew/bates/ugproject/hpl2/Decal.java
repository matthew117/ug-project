package uk.ac.dur.matthew.bates.ugproject.hpl2;

public class Decal
{

}
